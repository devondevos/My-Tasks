import React from 'react';
import avatar from './shorthair.png';
import './App.css';
import email from './email.png';
{/*For React JS to work, you have to import coding libraries*/}
function App() { {/*this is used to enable the code to work properly*/}
  return (
    <div className="App">
      <div className="pic" style={{textAlign:"center"}}> {/*add a heading with your picture and your details*/}
      	<img src={avatar} className="avatar" alt="avatar" />
      	<p>Devon De Vos</p>
      	<p>Entry-Level Web Developer</p>
      	<img src={email} className="email" alt="email logo" /><a className="emailp" href="https://gmail.com/">devondevos2000@gmail.com</a> {/*add a link to the email address*/}
      </div>
      <div className="body"> {/*add a section where you add all your educational information and all your experiences*/}
      	<h2>Overview</h2>
      	<p>I see myself as a disciplined individual who has the capability to learn and adapt easily. I am committed with solid personal ethics. My strengths: focussing on an assignment given and display determination on completing what is expected of me. Willing to learn to broaden my skills. I am keen to take on challenges to utilize my skills, to be developed and trained to be the best as expected. Future goals: to study Software Programming and Development</p>
      	<p>I focused more on my HTML, CSS and Javascript. I also focused on Python, because I want to learn Software Development.</p>
      	<h2>Learning Experience</h2> {/*this is all my coding languages*/}
      	<h3>Python</h3>
      	<p>I learned Python 3</p>
      	<h3>Front-End</h3>
      	<ul>
      	<li>HTML 5</li>
      	<li>CSS</li>
      	<li>JavaScript</li>
      	</ul>
      	<h3>Back-End</h3>
      	<ul>
      	<li>JSON</li>
      	<li>JQuery</li>
      	<li>React</li>
      	</ul>
      	<p>This Website is build using React.js and CSS</p>
      </div>
    </div>
  );
}

export default App; {/*this is used to render the coding to show in the web browser*/}