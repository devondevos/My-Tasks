import React, { Component } from 'react';
import ReactDOM from "react-dom";
import img1 from "./creed.jpg";
import img2 from "./tomclancy.jpg";
import img3 from "./watchdogs.jpg";
import logo from './logo.svg';
import './App.css';
import './index.js';
import './button.js';

export default class Menu extends Component {
  render() {

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <button onclick="myFunction()" id="button" className="Sign-in">Sign-in</button>
      </header>
      <div className="information">
        <p>Ubisoft Entertainment is a French computer and videogame developer and publisher with headquarters in Montreuil-sous-Bois, France. It was founded in 1986 by five brothers, of which Yves Guillemot serves as chairman and CEO. The company consists of 26 studios spread across 18 countries.</p>
      </div>
      <div className="body">
        <h3>Welcome to Ubisoft</h3>
        <div className="item1">
        <img src={img1} className="Image1" alt="Assassin's Creed" />
        <p>Assassin's Creed Chronicles is a series of video games in the Assassin's Creed franchise. The series consists of three games developed by Climax Studios and published by Ubisoft. The games feature new protagonists and a design that is new to the franchise, a 2.5D world inspired by traditional brush paintings.</p>
        </div>
        <div className="item1">
        <img src={img2} className="Image1" alt="Tom Clancy's" />
        <p>Tom Clancy's The Division is an online-only action role-playing video game developed by Massive Entertainment and published in 2016 by Ubisoft, with assistance from Red Storm Entertainment, Ubisoft Reflections and Ubisoft Annecy, for Microsoft Windows, PlayStation 4 and Xbox One.</p>
        </div>
        <div className="item1">
        <img src={img3} className="Image1" alt="Watch Dogs 2" />
        <p>Watch Dogs is an action-adventure game, played from a third-person view. The player controls hacker Aiden Pearce, who uses his smartphone to control trains and traffic lights, infiltrate security systems, jam cellphones, access pedestrians' private information, and empty their bank accounts.</p>
        </div>

      </div>
    </div>
  );
  }
}