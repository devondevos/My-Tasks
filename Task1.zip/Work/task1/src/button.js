function myFunction() {
	document.getElementById('button').innerHTML = alert("Welcome Back");
}